<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recensioni Prodotti</title>
    <link rel="stylesheet" href="../css/style_recensioni.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
</head>
<body>

<?php
session_start(); // Assicurati di iniziare la sessione se non lo hai già fatto

if (isset($_GET['tipologia']) && isset($_GET['id_prodotto'])) {
    $tipologia = $_GET['tipologia'];
    $id_prodotto = $_GET['id_prodotto'];
    $nome = $_GET['nome'];
    $id_utente = $_SESSION['id']; // Assumi che l'id utente sia memorizzato in una sessione
}
?>
<div class="home">
    <a href="catalogo_utente_<?php echo $tipologia; ?>.php">             
        <span id="casa" class="material-symbols-outlined">home</span>
    </a>
</div>
<?php
$xmlFile = '../xml/catalogo_prodotti.xml';
$dom = new DOMDocument();
$dom->load($xmlFile);

// Trova tutti gli elementi 'recensione' nel file XML relativi all'id_prodotto desiderato
$xpath = new DOMXPath($dom);
$recensioni = $xpath->query("//recensione[@id_prodotto='$id_prodotto']");

// Mostra le recensioni in una tabella
if ($recensioni->length > 0) {
    echo '<h1>Recensioni Prodotto ' . $nome . '</h1>';
    echo '<table>';
    echo '<tr><th>Autore</th><th>Recensione</th><th>Data e Ora</th><th>Voto Utilità</th><th>Voto Supporto</th><th>Azione</th></tr>';

    foreach ($recensioni as $recensione) {
        $id_recensione = $recensione->getElementsByTagName("id_recensione")->item(0)->textContent;
        $autore = $recensione->getElementsByTagName("autore")->item(0)->textContent;
        $testo = $recensione->getElementsByTagName("testo")->item(0)->textContent;
        $data = $recensione->getElementsByTagName("data")->item(0)->textContent;
        $ora = $recensione->getElementsByTagName("ora")->item(0)->textContent;

        // Recupera attributi e valori da utilita e supporto
        $utilitaNode = $recensione->getElementsByTagName('utilita')->item(0);
        $id_utente_utilita = $utilitaNode->getAttribute('id_utente');
        $utilitaValue = $utilitaNode->getElementsByTagName('valore')->item(0)->textContent;

        $supportoNode = $recensione->getElementsByTagName('supporto')->item(0);
        $id_utente_supporto = $supportoNode->getAttribute('id_utente');
        $supportoValue = $supportoNode->getElementsByTagName('valore')->item(0)->textContent;

        echo '<tr>';
        echo '<td>' . $autore . '</td>';
        echo '<td>' . $testo . '</td>';
        echo '<td>' . $data . ' ' . $ora . '</td>';
        echo '<td>' . $utilitaValue . '</td>';
        echo '<td>' . $supportoValue . '</td>';
        echo '<td>';

        // Verifica se l'utente ha già votato questa recensione
        if ($utilitaValue == 0 && $supportoValue == 0) {
            // Se l'utente non ha ancora votato, mostra i pulsanti per il voto
            echo '<form action="utilita_supporto.php" method="post">';
            echo '<input type="hidden" name="id_recensione" value="' . $id_recensione . '"/>';
            echo '<input type="hidden" name="id_prodotto" value="' . $id_prodotto . '"/>';
            echo '<input type="hidden" name="tipologia" value="' . $tipologia . '"/>';
            
            
            // Pulsanti per il voto di utilità
            echo '<label class="uti" for="votoUtilita">Utilità (da 1 a 3): </label>';
            echo '<input class="util" type="number" name="votoUtilita" min="1" max="3" required/><br>';

            // Pulsanti per il voto di supporto
            echo '<label class="sup" for="votoSupporto">Supporto (da 1 a 5): </label>';
            echo '<input type="number" name="votoSupporto" min="1" max="5" required/>';

            echo '<button class="vota" type="submit" name="vota"><span id="done" title="Invia" class="material-symbols-outlined">
            done_outline
            </span></button>';
            echo '</form>';
        } else {
            echo '<p><span id="ver" class="material-symbols-outlined">
            verified
            </span></p>';
        }

        echo '</td>';
        echo '</tr>';
    }

    echo '</table>';
} else {
    echo '<p>Nessuna recensione disponibile.</p>';
}
?>
</body>
</html>