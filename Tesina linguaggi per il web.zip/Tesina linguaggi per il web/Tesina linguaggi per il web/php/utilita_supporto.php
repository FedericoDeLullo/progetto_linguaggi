<?php

require_once('connection.php');
session_start();
$xmlFile = '../xml/catalogo_prodotti.xml';

// Carica il file XML
$dom = new DOMDocument();
$dom->load($xmlFile);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['vota'])) {
    $id_recensione = $_POST['id_recensione'];
    $votoUtilita = $_POST['votoUtilita'];
    $votoSupporto = $_POST['votoSupporto'];
    $id_prodotto = $_POST['id_prodotto'];
    $tipologia = $_POST['tipologia'];
    $id_utente = $_SESSION['id'];
    $reputazione_utente = $_SESSION['reputazione'];

    // Trova la recensione con l'id_recensione specificato
    $xpath = new DOMXPath($dom);
    $recensioneNode = $xpath->query("//recensione[id_recensione='$id_recensione']")->item(0);

    // Verifica se la recensione esiste prima di procedere
    if ($recensioneNode) {
        $id_utente_rec = $recensioneNode->getAttribute("id_utente");

        // Imposta i voti di utilità e supporto
        $utilitaNode = $recensioneNode->getElementsByTagName("utilita")->item(0);
        $supportoNode = $recensioneNode->getElementsByTagName("supporto")->item(0);
        $n_valNode = $recensioneNode->getElementsByTagName("n_val")->item(0);

        // Aggiungi un nuovo nodo "valore" per "utilita"
        $valoreUtilitaNode = $utilitaNode->appendChild($dom->createElement("valore"));

        // Imposta l'attributo "id_utente" per "utilita"
        $valoreUtilitaNode->setAttribute("id_utente", $id_utente);

        // Imposta il valore di "valore" per "utilita"
        $valoreUtilitaNode->nodeValue = $votoUtilita;

        // Aggiungi un nuovo nodo "valore" per "supporto"
        $valoreSupportoNode = $supportoNode->appendChild($dom->createElement("valore"));

        // Imposta l'attributo "id_utente" per "supporto"
        $valoreSupportoNode->setAttribute("id_utente", $id_utente);

        // Imposta il valore di "valore" per "supporto"
        $valoreSupportoNode->nodeValue = $votoSupporto;
        
        //incrementa il numero delle valutazioni
        $valoreCorrente = intval($n_valNode->nodeValue);
        $nuovoValore = $valoreCorrente + 1;

        // Imposta il nuovo valore
        $n_valNode->nodeValue = $nuovoValore;

        // Salva il documento XML aggiornato
        $dom->save($xmlFile);

        $query = "SELECT reputazione FROM utenti WHERE id = $id_utente_rec";
        $result = $connessione->query($query);

       
        if ($result) {
            // Ottieni la reputazione attuale dell'utente che ha lasciato la recensione
            $row = $result->fetch_assoc();
            $reputazione_utente_rec = $row['reputazione'];
        
            // ... (esegui le operazioni necessarie sulla reputazione, ad esempio, somma il voto della recensione)
        
            // Aggiorna la reputazione dell'utente nel database
            $nuova_reputazione = $reputazione_utente_rec + $votoUtilita + $votoSupporto; // Modifica questa logica in base alle tue esigenze
            $update_query = "UPDATE utenti SET reputazione = $nuova_reputazione WHERE id = $id_utente_rec";
            
            // Esegui la query di aggiornamento
            $update_result = $connessione->query($update_query);
        
            if ($update_result) {
                // Aggiornamento della reputazione riuscito
                echo "Reputazione dell'utente aggiornata con successo.";
            } else {
                // Gestisci eventuali errori nell'aggiornamento
                echo "Errore nell'aggiornamento della reputazione: " . $connessione->error;
            }
        }
        

        

        header("Location: recensioni.php?id_prodotto=" . $id_prodotto . "&nome=" . $nome . "&tipologia=" . $tipologia);
    }
}
?>
