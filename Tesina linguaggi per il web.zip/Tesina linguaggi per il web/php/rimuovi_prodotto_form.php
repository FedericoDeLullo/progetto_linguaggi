<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rimuovi Prodotto</title>
    <link rel="stylesheet" href="../css/style_aggiungi.css">

</head>
<body>
<div class="home">
                    <a href="index_loggato_admin.php">
                <div class="home_link" title="home"><img src="../img/home1.png" alt="home"></div></a>
            </div>
          
    <h2>Rimuovi Prodotto</h2>  
    <div class="cont1">
    <form class="form1" action="rimuovi_prodotto.php" method="post">
        <label class="nome" for="nome">Nome Prodotto:</label>
        <input class="nome" type="text" name="nome" required><br>

        <input class="btn1" type="submit" value="Rimuovi Prodotto">
    </form>
</div>
</body>
</html>
