<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style_catalogo.css">

    <title>Recensioni</title>
</head>
<body>
<?php
// Verifica se è stato fornito un ID del prodotto nella query string
if (isset($_GET['id_prodotto'])) {
    $id_prodotto = $_GET['id_prodotto'];

    // Carica il file XML del catalogo
    $xmlFile = '../xml/catalogo_prodotti.xml';
    $dom = new DOMDocument();
    $dom->load($xmlFile);

    // Trova il prodotto nel file XML
    $xpath = new DOMXPath($dom);
    $prodottoNode = $xpath->query("//prodotto[id_prodotto=$id_prodotto]")->item(0);

    // Verifica se il nodo del prodotto esiste prima di procedere
    if ($prodottoNode) {
        // Mostra il modulo per lasciare una recensione
        echo '<form method="get" action="recensioni_prodotti.php">';
        echo '<input type="hidden" name="id_prodotto" value="' . $id_prodotto . '">';
        echo '<label for="recensione">Lascia una recensione:</label>';
        echo '<textarea name="recensione" rows="4" cols="50"></textarea>';
        echo '<input type="submit" value="Invia recensione">';
        echo '</form>';
    } else {
        echo 'Prodotto non trovato.';
    }
} else {
    echo 'ID del prodotto mancante.';
}
?>
<?php
// Verifica se è stata inviata una richiesta GET
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Verifica se sono stati inviati dati del modulo
    if (isset($_GET['id_prodotto']) && isset($_GET['recensione'])) {
        $id_prodotto = $_GET['id_prodotto'];
        $recensione = $_GET['recensione'];

        // Carica il file XML del catalogo
        $xmlFile = '../xml/catalogo_prodotti.xml';
        $dom = new DOMDocument();
        $dom->load($xmlFile);

        // Trova il prodotto nel file XML
        $xpath = new DOMXPath($dom);
        $prodottoNode = $xpath->query("//prodotto[id_prodotto=$id_prodotto]")->item(0);

        // Verifica se il nodo del prodotto esiste prima di procedere
        if ($prodottoNode) {
            // Crea o trova l'elemento 'recensioni'
            $recensioniNode = $prodottoNode->getElementsByTagName('recensioni')->item(0);
            if (!$recensioniNode) {
                $recensioniNode = $dom->createElement('recensioni');
                $prodottoNode->appendChild($recensioniNode);
            }

            // Aggiungi la recensione al prodotto
            $recensioneNode = $dom->createElement('recensione', $recensione);
            $recensioniNode->appendChild($recensioneNode);

            // Salva il file XML aggiornato
            $dom->save($xmlFile);

            echo 'Recensione salvata con successo.';
            header('Location:../html/recensione_ok.html');

        } else {
            echo 'Prodotto non trovato.';
        }
    } 
} else {
    echo 'Accesso non consentito.';
}
?>

</body>
</html>