<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lascia una Recensione</title>
    <link rel="stylesheet" href="../css/style_catalogo.css"> <!-- Sostituisci con il percorso corretto al tuo file CSS -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
</head>
<body>
    <div class="home">
        <a href="catalogo_utente.php">             
            <span id="casa" class="material-symbols-outlined">home</span>
        </a>
        
    </div>

    <?php
        require_once('connection.php');
session_start();
    // Verifica se è stato fornito un ID del prodotto nella query string
    if (isset($_GET['id_prodotto'])) {
        $id_prodotto = $_GET['id_prodotto'];
        $nome_prodotto = $_GET['nome'];
        $email_utente = $_SESSION['email']; // Sostituisci con il modo effettivo per ottenere l'email dell'utente
        ?>

        <form class="rew" method="post" action="recensioni_prodotti.php">
            <input type="hidden" name="id_prodotto" value="<?php echo $id_prodotto; ?>">
            <input type="hidden" name="autore" value="<?php echo $email_utente; ?>">
            <div class ="rec">
                <label for="recensione">Lascia una recensione per: <?php echo $nome_prodotto; ?>:</label>
            </div>
            <textarea class="text" name="recensione" rows="4" cols="50" required></textarea>
            <div class="voto">
                <label for="voto">Voto (da 1 a 5): </label>
                <input type="number" name="voto" min="1" max="5" required>
            </div>
            <div class ="send">
                <input class="button" type="submit" value="Lascia Recensione">
            </div>
        </form>

        <?php
    } else {
        echo 'ID del prodotto mancante.';
    }
    ?>
    <?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verifica se sono stati inviati dati del modulo
    if (isset($_POST['id_prodotto'], $_POST['autore'], $_POST['recensione'], $_POST['voto'])) {
        $id_prodotto = $_POST['id_prodotto'];
        $autore = $_POST['autore'];
        $recensione = $_POST['recensione'];
        $voto = $_POST['voto'];

        // Carica il file XML del catalogo
        $xmlFile = '../xml/catalogo_prodotti.xml';
        $dom = new DOMDocument();
        $dom->load($xmlFile);

        // Trova il prodotto nel file XML
        $xpath = new DOMXPath($dom);
        $prodottoNode = $xpath->query("//prodotto[id_prodotto=$id_prodotto]")->item(0);

        // Verifica se il nodo del prodotto esiste prima di procedere
        if ($prodottoNode) {
            // Crea o trova l'elemento 'recensioni'
            $recensioniNode = $prodottoNode->getElementsByTagName('recensioni')->item(0);
            if (!$recensioniNode) {
                $recensioniNode = $dom->createElement('recensioni');
                $prodottoNode->appendChild($recensioniNode);
            }

            // Crea l'elemento 'recensione'
            $recensioneNode = $dom->createElement('recensione');

            // Aggiungi gli elementi 'autore', 'testo' e 'voto' all'elemento 'recensione'
            $autoreNode = $dom->createElement('autore', $autore);
            $testoNode = $dom->createElement('testo', $recensione);
            $votoNode = $dom->createElement('voto', $voto);

            $recensioneNode->appendChild($autoreNode);
            $recensioneNode->appendChild($testoNode);
            $recensioneNode->appendChild($votoNode);

            // Aggiungi l'elemento 'recensione' all'elemento 'recensioni'
            $recensioniNode->appendChild($recensioneNode);

            // Salva il file XML aggiornato
            $dom->save($xmlFile);

            echo 'Recensione salvata con successo.';
            header('Location: ../html/recensione_ok.html');
        } else {
            echo 'Prodotto non trovato.';
        }
    } else {
        echo 'Dati del modulo mancanti.';
    }
}
?>


</body>
</html>