<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recensioni Prodotti</title>
    <link rel="stylesheet" href="../css/style_recensioni.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />

</head>
<body>
<div class="home">
    <a href="../php/catalogo_utente.php">             
      <span id="casa" class="material-symbols-outlined">
home
      </span>
     </a>
    </div>
    <?php
// Carica il file XML del catalogo
$xmlFile = '../xml/catalogo_prodotti.xml';
$dom = new DOMDocument();
$dom->load($xmlFile);



// Trova tutti gli elementi 'recensione' nel file XML
$recensioni = $dom->getElementsByTagName('recensione');

// Mostra le recensioni in una tabella
if ($recensioni->length > 0) {
    echo '<h1>Recensioni Prodotto</h1>';
    echo '<table>';
    echo '<tr><th>Autore</th><th>Recensione</th><th>Voto</th></tr>';
    foreach ($recensioni as $recensione) {
        $autore = $recensione->getElementsByTagName("autore")->item(0)->textContent;
        $testo = $recensione->getElementsByTagName("testo")->item(0)->textContent;
        $voto = $recensione->getElementsByTagName("voto")->item(0)->textContent;

        echo '<tr><td>' . $autore . '</td><td class="recensione-cell">' . $testo . '</td><td>' . $voto . '</td></tr>';
    }
    echo '</table>';
}else {
    echo '<p>Nessuna recensione disponibile.</p>';
}
?>


</body>
</html>
